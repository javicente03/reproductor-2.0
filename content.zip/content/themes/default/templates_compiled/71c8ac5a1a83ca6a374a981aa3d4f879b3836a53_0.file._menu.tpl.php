<?php
/* Smarty version 3.1.40, created on 2022-05-18 17:24:53
  from 'C:\xampp\htdocs\nuevo reproductor\content\themes\default\templates\_menu.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62852be589c666_94597020',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '71c8ac5a1a83ca6a374a981aa3d4f879b3836a53' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevo reproductor\\content\\themes\\default\\templates\\_menu.tpl',
      1 => 1652894678,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:_playlist.tpl' => 1,
  ),
),false)) {
function content_62852be589c666_94597020 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="wrapper">

    <div id="bg">
        <div class="logo">
            <div class="cover"></div>
        </div>
    </div>

    <a ajax="no" href="http://hqradio.ru/" id="logo"></a>

    <div id="list">
        <a class="close" id="close_list"><i class="material-icons">close</i></a>
        <a href="http://hqradio.ru/favorites" id="fav_mode" class="fav function icon-fav"></a>
        <form id="search_form" data-url="data/search.php?do=search">
            <input class="icon-search" name="search" placeholder="Find and listen to your favorate music..."" id="search" autocomplete="off" type="search">
        </form>

        <div class="scroll">

            <section id="filter"></section>

            <section class="item-menu">
                <a class="header" href=""><i class="material-icons ipanel">layers</i>About</a>
                <hr>
            </section>

            <section class="item-menu">
                <a class="header" href=""><i class="material-icons ipanel">radio</i>Playlist</a>
                <hr>
            </section>

            <section class="item-menu">
                <a class="header" href=""><i class="material-icons ipanel">mic</i>Our team</a>
                <hr>
            </section>

            <section class="item-menu">
                <a class="header" href=""><i class="material-icons ipanel">album</i>Contacts</a>
                <hr>
            </section>

            <section class="item-menu">
                <a class="header" href=""><i class="material-icons ipanel">shop</i>Shop</a>
                <hr>
            </section>

            <section class="item-menu">
                <a class="header" href=""><i class="material-icons ipanel">radio</i>Radio</a>
                <hr>
            </section>

            <section class="item-menu">
                <a class="header" href=""><i class="material-icons ipanel">list</i>Reggaeton</a>
                <hr>
            </section>

            <section class="item-menu">
                <a class="header" href=""><i class="material-icons ipanel">chat</i>Chat</a>
                <hr>
            </section>

            <section id="stations" class="item-menu">
                <div class="ajax" id="playlist">
                <?php $_smarty_tpl->_subTemplateRender("file:_playlist.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

                </div>
                <hr>
            </section>
        </div>
    </div>
</div><?php }
}
