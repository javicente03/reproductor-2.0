<?php
/* Smarty version 3.1.40, created on 2022-05-18 17:49:30
  from 'C:\xampp\htdocs\nuevo reproductor\content\themes\default\templates\_head_radio.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_628531aa9c31c4_33542282',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '23f9f577de71ca88a05bdfc355db9d3b1fe4a97d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevo reproductor\\content\\themes\\default\\templates\\_head_radio.tpl',
      1 => 1652896168,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628531aa9c31c4_33542282 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en" class="_set-background-default _set-cover-rotate _set-blure-0 _set-find_cover-0">

<!-- Mirrored from hqradio.ru/stations/pmn-undgnd-_di-radio-com by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 17 May 2022 15:27:18 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <!--    <?php echo '<script'; ?>
>
            window.onerror = function (msg, url, line) {
                alert(msg + "\n" + url + "\n" + "\n" + line);
                return true;
            };
        <?php echo '</script'; ?>
>-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>PMN UNDGND. di-radio.com station online слушать бесплатно станцию онлайн | HQ Radio online | Радио онлайн</title>
    <meta name="description" content="Listen PMN UNDGND. di-radio.com Free high quality internet online radio catalog | Бесплатное интернет радио высокого качества слушать онлайн каталог"/>
    <meta name="keywords" content="PMN UNDGND.,di-radio.com,radio,online,mp3,flac,aac,192,320,hq,радио,онлайн,каталог,агрегатор,catalog,aggregator"/>
    <meta name="yandex-verification" content="4430bc017be8a0ba"/>

    <meta property="og:title" content="PMN UNDGND. - di-radio.com | HQ Radio"/>
    <meta property="og:description" content="PMN UNDGND. - di-radio.com listen online | Слушать онлайн"/>
    <meta property="og:image" content="http://hqradio.ru/data/covers/333.jpg"/>
    <meta property="og:url" content="pmn-undgnd-_di-radio-com.html"/>
    <meta property="og:site_name" content="HQ Radio | hqradio.ru"/>


    <meta name="theme-color" content="#222222">


    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/includes/assets/theme_dark/css/formse192.css?1633537680">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/includes/assets/theme_dark/css/iconse863.css?1623234756">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/includes/assets/theme_dark/css/main861a.css?1636714570">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/includes/assets/css/modals.css">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/includes/assets/theme_dark/css/adaptive2c98.css?1636714643">

    <!-- <?php echo '<script'; ?>
 src="js/hls.js"><?php echo '</script'; ?>
> -->
    <!-- <?php echo '<script'; ?>
 src="js/jquery.min.js"><?php echo '</script'; ?>
> -->

    <!-- <?php echo '<script'; ?>
 src="js/main2b91.js?1633369632"><?php echo '</script'; ?>
> -->


    <?php echo '</script'; ?>
>
    <noscript>
        <div><img src="../../mc.yandex.ru/watch/40289239.16.delayed" style="position:absolute; left:-9999px;" alt=""/></div>
    </noscript>
</head>
<body class="_mod_stations _player _logo _black paused">

<!-- Loading -->
  <div id="loading-page" class="loading show">
    <div class="disco">
      <div class="disco--cover"></div>
      <div class="disco--vinilo"></div>
    </div>
  </div>
  <!-- Fin loading -->  

<div class="ready-page" style="visibility: hidden;"><?php }
}
