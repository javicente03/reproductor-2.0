<?php
/* Smarty version 3.1.40, created on 2022-05-04 03:10:40
  from 'C:\xampp\htdocs\reproductor\content\themes\default\templates\_header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_6271eeb08bcf70_91288731',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd42971fbd0faa8c12ea5ccd10c77c3c6d7edcec3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\reproductor\\content\\themes\\default\\templates\\_header.tpl',
      1 => 1651633838,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6271eeb08bcf70_91288731 (Smarty_Internal_Template $_smarty_tpl) {
?><nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Double Sound</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
</nav><?php }
}
