<?php
/* Smarty version 3.1.40, created on 2022-05-17 18:00:09
  from 'C:\xampp\htdocs\nuevo reproductor\content\themes\default\templates\_js_files.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_6283e2a9cca077_37213214',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e0461de1a8db8507057886ce2cd242892778f510' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevo reproductor\\content\\themes\\default\\templates\\_js_files.tpl',
      1 => 1651891792,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6283e2a9cca077_37213214 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- Initialize --><?php echo '<script'; ?>
>/* initialize vars */var site_path = "<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
";<?php echo '</script'; ?>
><?php }
}
