<?php
/* Smarty version 3.1.40, created on 2022-05-04 21:36:37
  from 'C:\xampp\htdocs\reproductor\content\themes\default\templates\_menu_radio.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_6272f1e51d7589_89116990',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a73f901eaab9277767e442c8c065c2bb67aadae5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\reproductor\\content\\themes\\default\\templates\\_menu_radio.tpl',
      1 => 1651700190,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6272f1e51d7589_89116990 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="center">
	    <div class="left">
	    	<div class="controls">
	        	<div class="close"></div>
	        	<div class="minimize"></div>
	        	<div class="maximize"></div>
	      	</div>
		    <div class="menu">
		        <div class="title">MENU</div>
		        <div class="item"><i class="material-icons">layers</i><span>About</span></div>
		        <div class="item"><i class="material-icons">radio</i><span>Playlist</span></div>
		        <div class="item"><i class="material-icons">mic</i><span>Our team</span></div>
		        <div class="item"><i class="material-icons">album</i><span>Contacts</span></div>
		        <div class="item"><i class="material-icons">shop</i><span>Shop</span></div>
		    </div>
		    <div class="playlists">
		      	<div class="title">OTHERS</div>
		        <div class="item"><i class="material-icons">radio</i><span>Radio</span></div>
		        <div class="item"><i class="material-icons">list</i><span>Reggaeton</span></div>
		        <div class="item"><i class="material-icons">chat</i><span>Chat</span></div>
		    </div>
	    </div>
	</div><?php }
}
