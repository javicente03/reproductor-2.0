<?php
/* Smarty version 3.1.40, created on 2022-05-06 20:09:06
  from 'C:\xampp\htdocs\reproductor\content\themes\default\templates\_js_files.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62758062adea72_39214133',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0639eff06564d6f8d500c213f1e7db68f3695917' => 
    array (
      0 => 'C:\\xampp\\htdocs\\reproductor\\content\\themes\\default\\templates\\_js_files.tpl',
      1 => 1651867044,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62758062adea72_39214133 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- Initialize --><?php echo '<script'; ?>
>/* initialize vars */var site_path = "<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
";<?php echo '</script'; ?>
><?php }
}
