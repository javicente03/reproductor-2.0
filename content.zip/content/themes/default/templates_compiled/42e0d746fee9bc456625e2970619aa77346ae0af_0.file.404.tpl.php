<?php
/* Smarty version 3.1.40, created on 2022-05-06 20:15:58
  from 'C:\xampp\htdocs\reproductor\content\themes\default\templates\404.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_627581fee6b9b8_38532201',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '42e0d746fee9bc456625e2970619aa77346ae0af' => 
    array (
      0 => 'C:\\xampp\\htdocs\\reproductor\\content\\themes\\default\\templates\\404.tpl',
      1 => 1651868153,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:_head_radio.tpl' => 1,
    'file:_footer.tpl' => 1,
  ),
),false)) {
function content_627581fee6b9b8_38532201 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:_head_radio.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="center">

	<div class="right">
		<h2>404 Page Not Found</h2>
	</div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:_footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
